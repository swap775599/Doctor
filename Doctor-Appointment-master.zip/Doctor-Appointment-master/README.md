# Doctor-Appointment
This is Doctor -Appointment project.Here any patient can login and book an appointment very easily and they will get an notification also after that they will check up in online throungh videocall.
This will help to consume your time and easily check up will done .
it will help to make social distancing and protect you from carona effect too.
